<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <!-- Set latest rendering mode for IE -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <title>PT. EXCO NUSANTARA INDONESIA - Indonesia's leading INTERNATIONAL MONEY BROKERS</title>

        <!-- Set viewport for mobile devices to zoom to 100% -->
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
        <!-- Loading fonts in the header makes it work in IE<9 -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>

        <!-- Including bootstrap 2.3.1 -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <!-- Including Font Awesome 3.0 styles -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- Including Slider styles -->
        <link rel="stylesheet" href="css/slider.css" />
        <!-- Including main template styles -->
        <link rel="stylesheet" href="css/main.css">

        <!-- Loading jQuery liblary from CDN with a local fallback when CDN not responding. 
             Version 2.0 is available but it is the same as 1.9.1 but without IE8 support -->
    	<!-- Load jQuery from CDN -->
        <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
        <!-- Check if "window" is available. If not that means jQuery didn't load from CDN so instead use local version (otherwise skip) -->
        <script>window.jQuery || document.write('<script src="js/jquery-1.9.1.min.js"><\/script>')</script>

        <!-- If the browser version of IE is less than 9 load HTML5 & CSS3 polyfills -->
        <!--[if lt IE 9]>
            <link rel="stylesheet" href="css/ie.css">
            <script type="text/javascript" src="js/html5shiv.min.js"></script>
            <script type="text/javascript" src="js/selectivizr.min.js"></script>       
        <![endif]-->
    </head>

    <body class="home">

        <!-- Popover modal box containing client login form -->
        <div id="customer-login" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">

            <!--div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h5 id="myModalLabel">Customer area login:</h5>
            </div--><!-- modal-header end -->

            <div class="modal-body">
                <p>Login</p>
                <input type="text" class="customer-login-input" name='login-input' placeholder="Login">
                <p>Password</p>
                <input type="password" class="customer-login-input" name='password-input' placeholder="Password">
            </div><!-- modal-body end -->
            
            <div class="modal-footer">
                <div class="customer-help-links">
                    <a href="#">Forgot your password?</a>
                </div>
                <button class="btn btn-primary">Login</button>
            </div><!-- modal-footer end -->

        </div><!-- customer-login end -->

        <!-- Start developing your site here -->
        <div class="main-page-wrapper">

            <div class="top-background">

                <div class="top-menu-wrapper">
<p style="text-align:center; padding-top:10px; color:#FF0004; font-weight:bold">Website in development progress</p>
                    <nav class="top-menu container">

                        <ul>
                            <!--li><a href="#"><i class="icon-phone"></i><strong> Phone support:</strong> 1-234-567-890</a></li>
                            <li><a href="#"><i class="icon-comment"></i><strong> Live caht</strong> support</a></li>
                            <li><a href="#"><i class="icon-envelope-alt"></i><strong> Submit</strong> a ticket</a></li-->
                            <li><a href="#" id="mobile-nav-button"><i class="icon-list-ul"></i><strong> Show/Hide</strong> a menu</a></li>
                            <!--li><a href="#customer-login" data-toggle="modal"><i class="icon-user"></i><strong> Customer</strong> login</a></li-->
                        </ul>

                    </nav> <!-- end top-menu -->

                </div> <!-- end top-menu-wrapper -->

                <div class="mobile-nav off"></div><!-- mobile-nav end -->

                <header class="container">
                    
                    <div class="row">

                        <div class="span4">
                            <h1 class="logo clearfix">
                                <a href="index.html"><img src="img/logo.png" alt="Exco Nusantara"></a>
                            </h1>
                        </div> <!-- end span4 -->
                    
                        <div class="span8">
                            
                            <nav class="main-menu">
                                <ul>
                                    <li><a href="index.php" data-description="welcome" class="current-menu-item">Home</a></li>
                                    <li><a href="about.html" data-description="our company">About</a></li>
                                    <li><a href="services.html" data-description="our services">Service</a></li>
                                    <li><a href="gallery.html" data-description="our pictures">Gallery</a></li>
                                    <li><a href="contact.html" data-description="and quotes">Contact</a></li>
                                </ul>
                            </nav> <!-- end main-menu -->

                        </div> <!-- end span8 -->

                    </div> <!-- end row -->

                    <hr />

                    <div id="slider-container" class="clearfix" >

                        <div class="sequence-theme">
                            <div id="sequence">

                                <img class="sequence-prev" src="img/bt-prev.png" alt="Previous Frame" />
                                <img class="sequence-next" src="img/bt-next.png" alt="Next Frame" />

                                <ul class="sequence-canvas">
                                    <li class="animate-in">
                                        <h2 class="title">International Money Brokers</h2>
                                        <!--h3 class="subtitle"><strong>Bank-beating</strong> international money transfers</h3>
                                        <!--ul class="slider-info">
                                            <li><img src="img/icons/16x16/dedicated-server.png" alt="feature"><strong>10</strong> GB disk space</li>
                                            <li><img src="img/icons/16x16/bandwidth.png" alt="feature"><strong>5</strong> TB bandwidth</li>
                                            <li><img src="img/icons/16x16/database.png" alt="feature"><strong>5</strong> MySQL databases</li>
                                            <li><img src="img/icons/16x16/email.png" alt="feature"><strong>10</strong> mailboxes</li>
                                        </ul>
                                        <div class="slider-cta">
                                            <a href="#" class="button"><strong>Buy</strong> this plan now »</a>
                                            <a href="#" class="button"><strong>View other</strong> plans »</a>
                                        </div-->
                                        <img class="slider-image" src="img/page-images/slider-image1.png" alt="Server">
                                    </li>
                                    <li>
                                        <h2 class="title">Need more power?</h2>
                                        <!--h3 class="subtitle"><strong>A world leader</strong> in professional brokerage activities</h3>
                                        <!--ul class="slider-info">
                                            <li><img src="img/icons/16x16/dedicated-server.png" alt="feature"><strong>50</strong> GB disk space</li>
                                            <li><img src="img/icons/16x16/bandwidth.png" alt="feature"><strong>20</strong> TB bandwidth</li>
                                            <li><img src="img/icons/16x16/database.png" alt="feature"><strong>50</strong> <span class="hidden-phone">MySQL </span>databases</li>
                                            <li><img src="img/icons/16x16/email.png" alt="feature"><strong>Unlimited</strong> mailboxes</li>
                                        </ul>
                                        <div class="slider-cta">
                                            <a href="#" class="button"><strong>Buy</strong> this plan now »</a>
                                            <a href="#" class="button"><strong>View other</strong> plans »</a>
                                        </div-->
                                        <img class="slider-image" src="img/page-images/slider-image2.png" alt="Server">
                                    </li>
                                    <li>
                                        <h2 class="title"><strong>A global product offering</strong></h2>
                                        <!--h3 class="subtitle"><strong>We provide brokerage services</strong> in a comprehensive range of financial and commodity-related markets.</h3>
                                        <!--ul class="slider-info">
                                            <li><img src="img/icons/16x16/dedicated-server.png" alt="feature"><strong>20</strong> GB disk space</li>
                                            <li><img src="img/icons/16x16/bandwidth.png" alt="feature"><strong>6</strong> TB bandwidth</li>
                                            <li><img src="img/icons/16x16/database.png" alt="feature"><strong>9</strong> MySQL databases</li>
                                            <li><img src="img/icons/16x16/email.png" alt="feature"><strong>20</strong> mailboxes</li>
                                        </ul>
                                        <div class="slider-cta">
                                            <a href="#" class="button"><strong>Buy</strong> this plan now »</a>
                                            <a href="#" class="button"><strong>View other</strong> plans »</a>
                                        </div-->
                                        <img class="slider-image" src="img/page-images/slider-image3.png" alt="Server">
                                    </li>
                                </ul>

                                <ul class="sequence-pagination">
                                  <li><img src="img/page-images/slider-image1.png" alt="Model 1" /></li>
                                    <li><img src="img/page-images/slider-image2.png" alt="Model 2" /></li>
                                    <li><img src="img/page-images/slider-image3.png" alt="Model 3" /></li>
                                </ul>

                            </div>
                        </div>

                    </div> <!-- slider-container end -->
               
                </header> <!-- end container -->

            </div><!-- top-background end -->

            <section id="content">
            <div class="white-section"><div class="container">
            <div class="row" style="text-align:center">
            <img style="width:100%; max-width:857px; margin:50px 0" src="img/update.jpg"/>
               </div></div></div>
                <div class="white-section">
                    
                    <div class="container">


                        <div class="row">
                        
                        <h1 class="span12 homepage-style">What We Serve</h1>
<p class="span12" style="text-align:justify">Exco Nusantara Indonesia offering intermediary services for the interest of its costumers in the area of Money Market both in Indonesian Rupiah and Foreign Currencies, Goverment Bill, Goverment Bond which includes the following products :</p>
                            
                                <!--h4>Advanced technologies:</h4>
                                <p>Lorem ipsum dolor sit amet, consectu adipisi cing elit. Ab expedita sintpara accusamus impedit repellendus amit assumenda quo facilis modi sunt poro!</p>
                                <p>Ab expedita sintpara accusamus impedit repellendus amit assumenda quo facilis modi sunt poro!</p>
                                <ul class="features-list">
                                    <li><img src="img/icons/16x16/control-panel.png" alt="feature">Powerfull cPanel</li>
                                    <li><img src="img/icons/16x16/secure-server.png" alt="feature">Highest security rate</li>
                                    <li><img src="img/icons/16x16/website-builder.png" alt="feature">Easy website builder</li>
                                    <li><img src="img/icons/16x16/ftp.png" alt="feature">Dedicated FTP software</li>
                                    <li><img src="img/icons/16x16/bandwidth.png" alt="feature">Unlimited bandwidth</li>
                                    <li><img src="img/icons/16x16/domain-names.png" alt="feature">Free domain names</li>
                                    <li><img src="img/icons/16x16/iphone-control-panel.png" alt="feature">iPhone control Panel</li>
                                    <li><img src="img/icons/16x16/e-commerce.png" alt="feature">E-commerce solutions</li>
                                    <li><img src="img/icons/16x16/dedicated-server.png" alt="feature">Various disk spaces</li>
                                    <li><img src="img/icons/16x16/database.png" alt="feature">MySQL & PostageSQL Databases</li>
                                    <li><img src="img/icons/16x16/support.png" alt="feature">24/7 Live Support</li>
                                </ul>
                            </div><!-- span4 end -->

                            <div class="span6">
                                <div class="card-feature-bg">
                                    <div class="card-feature">
                                        <a href="#"><img src="img/icons/32x32/exchange.png" alt="feature" class="feature-icon">
                                        <h5>FOREX</h5>
                                        </a>
                                    </div><!-- card-feature end -->
                                </div><!-- card-feature-bg end -->

                                <div class="card-feature-bg">
                                    <div class="card-feature">
                                        <a href="#"><img src="img/icons/32x32/invoice.png" alt="feature" class="feature-icon">
                                        <h5>SWAP</h5>
                                        </a>
                                    </div><!-- card-feature end -->
                                </div><!-- card-feature-bg end -->
                                
                            </div><!-- span6 end -->

                            <div class="span6 ">
                                

                                <div class="card-feature-bg">
                                    <div class="card-feature">
                                        <a href="#"><img src="img/icons/32x32/switch.png" alt="feature" class="feature-icon">
                                        <h5>FORWARD</h5>
                                        </a>
                                    </div><!-- card-feature end -->
                                </div><!-- card-feature-bg end -->
                                <div class="card-feature-bg">
                                    <div class="card-feature">
                                        <a href="#"><img src="img/icons/32x32/quality.png" alt="feature" class="feature-icon">
                                        <h5>MONEY MARKET</h5>
                                        </a>
                                    </div><!-- card-feature end -->
                                </div><!-- card-feature-bg end -->
                            </div><!-- span6 end -->
<div class="span12 sendiri">
<div class="card-feature-bg">
                                    <div class="card-feature">
                                    <a data-toggle="modal" href="#defaultModal">
                                        <img src="img/icons/32x32/switch.png" alt="feature" class="feature-icon">
                                        <h5>FIXED INCOME</h5></a>
                                        
                                    </div><!-- card-feature end -->
                                </div><!-- card-feature-bg end -->
</div>
                        <!-- row end -->

                    </div><!-- container end -->

                </div></div><!-- white-section end --><!-- blue-section end -->

                <!-- white-section end -->

            </section><!-- content end -->

            <footer id="footer">

                <div class="container"><!-- row end -->


                    <!-- this is a container for the newsletter fail or success message -->
                    <div id='message_post2'></div><!-- message_post2 end -->

                    <hr />

                    <div class="row">

                        <p class="span12">© Copyright 2017. PT Exco Nusantara. All rights reserved. <span class="style1">Hit Counter : 
                <?php
include ("counter.php");
?>
		      </span></p>
                    
                    </div><!-- row end -->

              </div><!-- container end -->

                <a href="#" class="go-top" style="display: inline;">Go Top</a>
                
            </footer>

        </div><!-- end main-page-wrapper -->
        
        <div class="modal fade" id="defaultModal" tabindex="-1" role="dialog" aria-labelledby="defaultModalLabel" aria-hidden="true">
										<div class="modal-dialog">
											<div class="modal-content">
												<div class="modal-header">
													<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
													<h4 class="modal-title" id="defaultModalLabel" style="color:#FFF; text-align:center">FIXED INCOME</h4>
												</div>
												<div class="modal-body">
													<p style="color:#222222; font-size:16px;">FIXED INCOME PRODUCTS</p>
  <div style="clear:both">&nbsp;</div>
<ol>
  <li><strong>IDR TREASURY BILL</strong><br>
  Short-term government securities with maturities ranging from a few days up to 13 months
    <!--Surat berharga pemerintah berjangka pendek dengan jatuh tempo berkisar dari beberapa hari sampai dengan 13 bulan--><br>
    <br>
  </li>
  <li><strong>IDR GOVT BONDS
    
    </strong><br>
    Long-term government securities with maturities of issuance of more than 5 years, with a fixed interest
    <!--Surat berharga pemerintah berjangka panjang dengan jangka waktu penerbitan lebih dari 5 tahun, dengan bunga tetap.--> <br>
    - SUBDEBT, OBLOGASI FR ( Fixed Rate ) <br><br>
  </li>
  <li><strong>IDR RECAP BONDS
    
    </strong><br>
    Government securities with fixed interest rate or floating interest payments every 3 months (Quarterly)
    <!--Surat berharga pemerintah dengan tingkat suku bunga tidak tetap atau mengambang dan pembayaran bunga setiap 3 bulan ( Kuartalan )-->
    <br>
    - INDORB FLOAT. OBLIGASI VR ( Variabel Rate ) <br><br>
  </li>
  <li><strong>IDR GOVT INTERNATIONAL BONDS
    
    </strong><br>
    Bonds issued by the central government, the minister / BI, do not have the risk of failure, bond prices will fall if interest rates rise.
    <!--Surat obligasi yang diterbitkan oleh pemerintah pusat, Menkeu/BI, tidak memiliki resiko kegagalan, harga obligasi akan turun jika suku bunga naik.--> <br>
    - INDON <br>
    <br>
  </li>
  <li><strong>IDR RETAIL BONDS
    
    </strong><br>
    Bonds that are traded in units smaller nominal value, corporate bonds and government bonds.
    <!--Surat obligasi yang diperjual belikan dalam satuan nilai nominal yang kecil, corporate bonds maupun government bonds.--><br>
    - INDORI, ORI ( Obligasi Ritel Indonesia ) <br>
    <br>
  </li>
  <li><strong>IDR SUKUK BONDS
    
    </strong><br>
    Sharia securities issued and sales regulated by the State, namely the Ministry of Finance (MoF)
    <!--Surat berharga Syariah yang diterbitkan dan penjualannya diatur oleh Negara, yaitu Departemen Keuangan ( Depkeu ).--><br>
    - INDOIS, SR ( Sukuk Retail ), PBS (Project Based Sukuk ), SPM ( Surat Perbendaharaan Neraca) <br>
    <br>
  </li>
  <li><strong>CSS / IRS
    
    </strong><br>
    - CSS ( Cross Current Swap) <br>
    An agreement between the two Party to redeem its principal and interest payments in the form of different currencies. Principal exchange using the exchange rate at inception
    <!--Merupakan suatu agreement antara dua Party untuk menukarkan principal dan pembayaran
 interest nya dalam bentuk mata uang yang berbeda.  Penukaran principal menggunakan exchange rate pada saat dimulainya transaksi--> <br>
    - IRS ( Interest Rate Swap)<br>
An agreement between two parties to exchange a series / series are fixed interest payments in one currency with series / series are floating interst payments in the same currency (or vice versa)
    
    <!--Merupakan kesepakatan antara dua pihak untuk melakukan pertukaran seri/rangkaian pembayaran interest secara fixed dalam satu mata uang dengan seri/rangkaian pembayaran
 interst secara floating dalam mata uang yang sama (atau sebaliknya).--></li>
</ol>

												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												</div>
											</div>
										</div>
									</div>

        <!-- Loading all JS files the asynchronous way -->
        <!-- Twitter Bootstrap JavaScript file required for transitions, pupups, modals and other elements  -->
        <script src="js/bootstrap.min.js"></script>

        <!-- Slider script -->
        <script src="js/jquery.sequence-min.js"></script>

        <!-- Main file containing all other scripts. This is done to avoid multiple HTTP requests -->
        <script src="js/main.js"></script>

    </body>
</html>
